package com.namma.metrosahaya.ui

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
    val isKannada = MutableLiveData(false)

    fun toggleLanguage() {
        isKannada.value = !(isKannada.value ?: false)
    }
}
