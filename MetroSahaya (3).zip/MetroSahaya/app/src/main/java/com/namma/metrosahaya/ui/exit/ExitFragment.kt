package com.namma.metrosahaya.ui.exit

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.namma.metrosahaya.databinding.FragmentExitBinding
import com.namma.metrosahaya.ui.MainViewModel
import com.namma.metrosahaya.ui.adapter.ExitAdapter

class ExitFragment : Fragment() {

    private var _binding: FragmentExitBinding? = null
    private val binding get() = _binding!!

    private val viewModel: ExitViewModel by viewModels()
    private val mainViewModel: MainViewModel by viewModels({ requireActivity() })
    private lateinit var exitAdapter: ExitAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentExitBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupObservers()
    }

    private fun setupRecyclerView() {
        exitAdapter = ExitAdapter(false)
        binding.rvExits.layoutManager = LinearLayoutManager(requireContext())
        binding.rvExits.adapter = exitAdapter
    }

    private fun setupObservers() {
        val isKannada = mainViewModel.isKannada.value == true

        viewModel.stationsWithExits.observe(viewLifecycleOwner) { stations ->
            val names = stations.map { if (isKannada) it.nameKannada else it.name }
            val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, names)
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            binding.spinnerStation.adapter = adapter

            binding.spinnerStation.setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    stations.getOrNull(position)?.let { viewModel.selectStation(it.id) }
                }
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            })
        }

        viewModel.exits.observe(viewLifecycleOwner) { exits ->
            exitAdapter.updateData(exits, mainViewModel.isKannada.value == true)
            binding.tvNoExits.visibility = if (exits.isEmpty()) View.VISIBLE else View.GONE
        }

        mainViewModel.isKannada.observe(viewLifecycleOwner) { kannada ->
            exitAdapter.updateLanguage(kannada)
            binding.tvExitHint.text = if (kannada)
                "💡 ಪ್ಲಾಟ್‌ಫಾರ್ಮ್‌ನಲ್ಲಿ ಹಸಿರು ಬಾಣದ ಚಿಹ್ನೆ ಅನುಸರಿಸಿ"
            else
                "💡 Follow the green arrow signs on the platform for exits"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
