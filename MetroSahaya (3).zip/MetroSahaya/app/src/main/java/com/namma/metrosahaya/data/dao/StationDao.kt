package com.namma.metrosahaya.data.dao

import androidx.room.*
import com.namma.metrosahaya.data.entity.StationEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface StationDao {

    @Query("SELECT * FROM stations ORDER BY line, orderIndex ASC")
    fun getAllStations(): Flow<List<StationEntity>>

    @Query("SELECT * FROM stations WHERE line = :line ORDER BY orderIndex ASC")
    suspend fun getStationsByLine(line: String): List<StationEntity>

    @Query("SELECT * FROM stations WHERE id = :id LIMIT 1")
    suspend fun getStationById(id: String): StationEntity?

    @Query("SELECT COUNT(*) FROM stations")
    suspend fun getCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(stations: List<StationEntity>)

    @Query("SELECT * FROM stations WHERE isInterchange = 1")
    suspend fun getInterchangeStations(): List<StationEntity>
}
