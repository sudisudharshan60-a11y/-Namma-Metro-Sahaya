package com.namma.metrosahaya

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.namma.metrosahaya.databinding.ActivityMainBinding
import com.namma.metrosahaya.ui.MainViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val mainViewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        val navController = navHostFragment.navController

        binding.bottomNavigation.setupWithNavController(navController)

        binding.btnLanguage.setOnClickListener {
            mainViewModel.toggleLanguage()
        }

        mainViewModel.isKannada.observe(this) { isKannada ->
            binding.btnLanguage.text = if (isKannada) "EN" else "ಕನ್ನಡ"
            binding.tvAppTitle.text = if (isKannada) "ನಮ್ಮ ಮೆಟ್ರೋ ಸಹಾಯ" else "Namma-Metro Sahaya"
            binding.tvAppSubtitle.text = if (isKannada)
                "ಮೊದಲ ಬಾರಿ ಮೆಟ್ರೋ ಮಾರ್ಗದರ್ಶಿ"
            else
                "First-Timer's Metro Guide"
        }
    }
}
