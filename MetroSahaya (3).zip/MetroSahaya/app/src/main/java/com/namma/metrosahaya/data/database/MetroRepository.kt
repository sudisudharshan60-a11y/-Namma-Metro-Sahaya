package com.namma.metrosahaya.data.database

import com.namma.metrosahaya.data.entity.ExitEntity
import com.namma.metrosahaya.data.entity.FareEntity
import com.namma.metrosahaya.data.entity.StationEntity
import com.namma.metrosahaya.model.MetroPathfinder
import com.namma.metrosahaya.model.RouteResult
import kotlinx.coroutines.flow.Flow

class MetroRepository(private val database: MetroDatabase) {

    // ── Stations ──────────────────────────────────────────────────────────
    fun getAllStations(): Flow<List<StationEntity>> =
        database.stationDao().getAllStations()

    suspend fun getStationsByLine(line: String): List<StationEntity> =
        database.stationDao().getStationsByLine(line)

    suspend fun getStationById(id: String): StationEntity? =
        database.stationDao().getStationById(id)

    // ── Exits ─────────────────────────────────────────────────────────────
    fun getExitsForStation(stationId: String): Flow<List<ExitEntity>> =
        database.exitDao().getExitsForStation(stationId)

    suspend fun getStationsWithExits(): List<String> =
        database.exitDao().getStationsWithExits()

    // ── Fares ─────────────────────────────────────────────────────────────
    fun getAllFares(): Flow<List<FareEntity>> =
        database.fareDao().getAllFares()

    suspend fun getFareForStops(stops: Int): Int =
        database.fareDao().getFareForStops(stops) ?: MetroPathfinder.calcFare(stops)

    // ── Route Finder (BFS pathfinding) ────────────────────────────────────
    suspend fun findRoute(fromId: String, toId: String): RouteResult? {
        val from = getStationById(fromId) ?: return null
        val to   = getStationById(toId)   ?: return null
        val all  = database.stationDao().getStationsByLine("purple") +
                   database.stationDao().getStationsByLine("green")
        return MetroPathfinder.findRoute(from, to, all)
    }

    // ── DB Init check ─────────────────────────────────────────────────────
    suspend fun isDatabaseSeeded(): Boolean =
        database.stationDao().getCount() > 0

    suspend fun seedIfEmpty() {
        if (!isDatabaseSeeded()) {
            DatabaseSeeder.seedData(database)
        }
    }
}
