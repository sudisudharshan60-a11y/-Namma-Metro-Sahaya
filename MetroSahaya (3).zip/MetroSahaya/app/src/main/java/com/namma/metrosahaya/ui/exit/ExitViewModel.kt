package com.namma.metrosahaya.ui.exit

import android.app.Application
import androidx.lifecycle.*
import com.namma.metrosahaya.data.database.MetroDatabase
import com.namma.metrosahaya.data.database.MetroRepository
import com.namma.metrosahaya.data.entity.ExitEntity
import com.namma.metrosahaya.data.entity.StationEntity
import kotlinx.coroutines.launch

class ExitViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = MetroRepository(MetroDatabase.getDatabase(application))

    private val _stationsWithExits = MutableLiveData<List<StationEntity>>()
    val stationsWithExits: LiveData<List<StationEntity>> = _stationsWithExits

    private val _selectedStationId = MutableLiveData<String>("maj")
    val selectedStationId: LiveData<String> = _selectedStationId

    val exits: LiveData<List<ExitEntity>> = _selectedStationId.switchMap { stationId ->
        repository.getExitsForStation(stationId).asLiveData()
    }

    init {
        loadStationsWithExits()
    }

    private fun loadStationsWithExits() {
        viewModelScope.launch {
            val ids = repository.getStationsWithExits()
            val stations = ids.mapNotNull { repository.getStationById(it) }
            _stationsWithExits.value = stations
        }
    }

    fun selectStation(stationId: String) {
        _selectedStationId.value = stationId
    }
}
