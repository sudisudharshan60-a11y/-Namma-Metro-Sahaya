package com.namma.metrosahaya.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "fares")
data class FareEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val minStops: Int,
    val maxStops: Int,
    val fareRupees: Int,
    val distanceKm: String
)
