package com.namma.metrosahaya.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "exits")
data class ExitEntity(
    @PrimaryKey(autoGenerate = true) val exitId: Int = 0,
    val stationId: String,
    val gateName: String,
    val gateNameKannada: String,
    val leadsTo: String,
    val leadsToKannada: String,
    val landmark: String
)
