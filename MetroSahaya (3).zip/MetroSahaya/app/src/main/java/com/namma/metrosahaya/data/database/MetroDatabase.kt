package com.namma.metrosahaya.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.namma.metrosahaya.data.dao.ExitDao
import com.namma.metrosahaya.data.dao.FareDao
import com.namma.metrosahaya.data.dao.StationDao
import com.namma.metrosahaya.data.entity.ExitEntity
import com.namma.metrosahaya.data.entity.FareEntity
import com.namma.metrosahaya.data.entity.StationEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [StationEntity::class, ExitEntity::class, FareEntity::class],
    version = 1,
    exportSchema = false
)
abstract class MetroDatabase : RoomDatabase() {

    abstract fun stationDao(): StationDao
    abstract fun exitDao(): ExitDao
    abstract fun fareDao(): FareDao

    companion object {
        @Volatile
        private var INSTANCE: MetroDatabase? = null

        fun getDatabase(context: Context): MetroDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MetroDatabase::class.java,
                    "metro_sahaya_db"
                )
                    .addCallback(object : RoomDatabase.Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Seed using a fresh reference after INSTANCE is set
                            CoroutineScope(Dispatchers.IO).launch {
                                INSTANCE?.let { DatabaseSeeder.seedData(it) }
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
