package com.namma.metrosahaya.model

import com.namma.metrosahaya.data.entity.StationEntity

data class RouteStep(
    val station: StationEntity,
    val stepType: StepType,
    val instruction: String,
    val instructionKannada: String
)

enum class StepType { START, STOP, INTERCHANGE, END }

data class RouteResult(
    val steps: List<RouteStep>,
    val totalStops: Int,
    val estimatedMinutes: Int,
    val fareRupees: Int,
    val hasInterchange: Boolean,
    val interchangeStationName: String = ""
)

object MetroPathfinder {

    /**
     * BFS / ordered-list pathfinding across Purple & Green lines.
     * Interchange is at Majestic (id = "maj" on purple, "maj2" on green).
     */
    fun findRoute(
        from: StationEntity,
        to: StationEntity,
        allStations: List<StationEntity>
    ): RouteResult? {
        if (from.id == to.id) return null

        val purpleStations = allStations.filter { it.line == "purple" }.sortedBy { it.orderIndex }
        val greenStations  = allStations.filter { it.line == "green"  }.sortedBy { it.orderIndex }

        return if (from.line == to.line) {
            // Same line – direct path
            val lineStations = if (from.line == "purple") purpleStations else greenStations
            val fromIdx = lineStations.indexOfFirst { it.id == from.id }
            val toIdx   = lineStations.indexOfFirst { it.id == to.id   }
            if (fromIdx < 0 || toIdx < 0) return null

            val path = lineStations.subList(
                minOf(fromIdx, toIdx),
                maxOf(fromIdx, toIdx) + 1
            ).let { if (fromIdx > toIdx) it.reversed() else it }

            buildResult(path, emptyList(), allStations)
        } else {
            // Cross-line – must go through Majestic
            val interchangePurple = purpleStations.firstOrNull { it.id == "maj"  } ?: return null
            val interchangeGreen  = greenStations.firstOrNull  { it.id == "maj2" } ?: return null

            val line1 = if (from.line == "purple") purpleStations else greenStations
            val line2 = if (to.line   == "purple") purpleStations else greenStations
            val ic1   = if (from.line == "purple") interchangePurple else interchangeGreen
            val ic2   = if (to.line   == "purple") interchangePurple else interchangeGreen

            val fi1 = line1.indexOfFirst { it.id == from.id }
            val fi2 = line1.indexOfFirst { it.id == ic1.id  }
            val fi3 = line2.indexOfFirst { it.id == ic2.id  }
            val fi4 = line2.indexOfFirst { it.id == to.id   }
            if (fi1 < 0 || fi2 < 0 || fi3 < 0 || fi4 < 0) return null

            val part1 = line1.subList(minOf(fi1, fi2), maxOf(fi1, fi2) + 1)
                .let { if (fi1 > fi2) it.reversed() else it }
            val part2 = line2.subList(minOf(fi3, fi4), maxOf(fi3, fi4) + 1)
                .let { if (fi3 > fi4) it.reversed() else it }

            buildResult(part1, part2, allStations)
        }
    }

    private fun buildResult(
        part1: List<StationEntity>,
        part2: List<StationEntity>,
        allStations: List<StationEntity>
    ): RouteResult {
        val steps = mutableListOf<RouteStep>()

        part1.forEachIndexed { i, station ->
            val type = when {
                i == 0 && part2.isEmpty() && part1.size == 1 -> StepType.END
                i == 0 -> StepType.START
                i == part1.size - 1 && part2.isNotEmpty() -> StepType.INTERCHANGE
                i == part1.size - 1 -> StepType.END
                else -> StepType.STOP
            }
            steps.add(RouteStep(station, type, instructionEn(type), instructionKn(type)))
        }

        part2.drop(1).forEachIndexed { i, station ->
            val type = if (i == part2.size - 2) StepType.END else StepType.STOP
            steps.add(RouteStep(station, type, instructionEn(type), instructionKn(type)))
        }

        val totalStops = (part1.size - 1) + (part2.size - 1).coerceAtLeast(0)
        val fare = calcFare(totalStops)

        return RouteResult(
            steps = steps,
            totalStops = totalStops,
            estimatedMinutes = (totalStops * 2.5).toInt().coerceAtLeast(1),
            fareRupees = fare,
            hasInterchange = part2.isNotEmpty(),
            interchangeStationName = if (part2.isNotEmpty()) "Majestic" else ""
        )
    }

    private fun instructionEn(type: StepType) = when (type) {
        StepType.START       -> "Board the metro here"
        StepType.STOP        -> "Stay on the train"
        StepType.INTERCHANGE -> "Change lines here – go to upper/lower platform"
        StepType.END         -> "Get off here – you have arrived!"
    }

    private fun instructionKn(type: StepType) = when (type) {
        StepType.START       -> "ಇಲ್ಲಿಂದ ಮೆಟ್ರೋ ಏರಿ"
        StepType.STOP        -> "ರೈಲಿನಲ್ಲಿ ಇರಿ"
        StepType.INTERCHANGE -> "ಇಲ್ಲಿ ಸಾಲು ಬದಲಾಯಿಸಿ – ಮೇಲಿನ ಅಥವಾ ಕೆಳ ಪ್ಲಾಟ್‌ಫಾರ್ಮ್"
        StepType.END         -> "ಇಲ್ಲಿ ಇಳಿಯಿರಿ – ನೀವು ತಲುಪಿದ್ದೀರಿ!"
    }

    fun calcFare(stops: Int) = when {
        stops <= 1  -> 10
        stops <= 2  -> 15
        stops <= 3  -> 20
        stops <= 5  -> 25
        stops <= 8  -> 30
        else        -> 40
    }
}
