package com.namma.metrosahaya.ui.route

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.namma.metrosahaya.R
import com.namma.metrosahaya.data.entity.StationEntity
import com.namma.metrosahaya.databinding.FragmentRouteBinding
import com.namma.metrosahaya.model.StepType
import com.namma.metrosahaya.ui.MainViewModel

class RouteFragment : Fragment() {

    private var _binding: FragmentRouteBinding? = null
    private val binding get() = _binding!!

    private val viewModel: RouteViewModel by viewModels()
    private val mainViewModel: MainViewModel by viewModels({ requireActivity() })

    private var stationList = listOf<StationEntity>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRouteBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupObservers()
        setupClickListeners()
    }

    private fun setupObservers() {

        viewModel.allStations.observe(viewLifecycleOwner) { stations ->
            stationList = stations
            setupSpinners(stations)
        }

        viewModel.isLoading.observe(viewLifecycleOwner) { loading ->
            binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
            binding.btnFindRoute.isEnabled = !loading
        }

        viewModel.error.observe(viewLifecycleOwner) { error ->
            error?.let {
                Toast.makeText(requireContext(), it, Toast.LENGTH_LONG).show()
                binding.cardResult.visibility = View.GONE
            }
        }

        viewModel.routeResult.observe(viewLifecycleOwner) { result ->
            if (result != null) {
                binding.cardResult.visibility = View.VISIBLE
                binding.tvStops.text = result.totalStops.toString()
                binding.tvMinutes.text = "~${result.estimatedMinutes}"
                binding.tvFare.text = "₹${result.fareRupees}"

                val isKannada = mainViewModel.isKannada.value == true

                if (result.hasInterchange) {
                    binding.tvInterchangeNote.visibility = View.VISIBLE
                    binding.tvInterchangeNote.text = if (isKannada)
                        "⚠ ಮೆಜಸ್ಟಿಕ್‌ನಲ್ಲಿ ಸಾಲು ಬದಲಾಯಿಸಿ"
                    else
                        "⚠ Change lines at Majestic station"
                } else {
                    binding.tvInterchangeNote.visibility = View.GONE
                }

                binding.tvTokenSteps.text = if (isKannada) {
                    "1. ಯಂತ್ರದ ಪರದೆ ಮುಟ್ಟಿ\n2. \"Token\" ಆಯ್ಕೆ ಮಾಡಿ\n3. ನಿಮ್ಮ ಗಮ್ಯ ಆಯ್ಕೆ ಮಾಡಿ\n4. Rs.${result.fareRupees} ನಾಣ್ಯ / ನೋಟು ಹಾಕಿ\n5. ಟೋಕನ್ ಪಡೆಯಿರಿ"
                } else {
                    "1. Touch the machine screen\n2. Select Token\n3. Select your destination\n4. Insert Rs.${result.fareRupees} coins or notes\n5. Collect your token"
                }

                updateStepCounter()
            }
        }

        viewModel.currentStepData.observe(viewLifecycleOwner) { step ->
            step ?: return@observe
            val isKannada = mainViewModel.isKannada.value == true
            val station = step.station

            binding.tvStepStation.text = if (isKannada) station.nameKannada else station.name
            binding.tvStepInstruction.text =
                if (isKannada) step.instructionKannada else step.instruction

            val lineColor = if (station.line == "purple")
                ContextCompat.getColor(requireContext(), R.color.purple_line)
            else
                ContextCompat.getColor(requireContext(), R.color.green_line)

            binding.tvLineTag.text =
                if (station.line == "purple") "Purple Line" else "Green Line"
            binding.viewLineAccent.setBackgroundColor(lineColor)

            binding.tvStepEmoji.text = when (step.stepType) {
                StepType.START       -> "Start"
                StepType.STOP        -> "On Train"
                StepType.INTERCHANGE -> "Change Line"
                StepType.END         -> "Arrived!"
            }

            if (station.isInterchange) {
                binding.tvInterchangeTip.visibility = View.VISIBLE
                binding.tvInterchangeTip.text = if (isKannada)
                    "Purple <-> Green - ಮೇಲಿನ ಅಥವಾ ಕೆಳ ಪ್ಲಾಟ್ಫಾರ್ಮ್"
                else
                    "Purple <-> Green - Go to upper or lower platform"
            } else {
                binding.tvInterchangeTip.visibility = View.GONE
            }

            updateStepCounter()
        }

        viewModel.currentStep.observe(viewLifecycleOwner) { _ ->
            updateStepCounter()
            updateNavButtons()
        }

        mainViewModel.isKannada.observe(viewLifecycleOwner) { _ ->
            setupSpinners(stationList)
            viewModel.refreshCurrentStep()
        }
    }

    private fun setupSpinners(stations: List<StationEntity>) {
        val isKannada = mainViewModel.isKannada.value == true
        val names = stations.map { if (isKannada) it.nameKannada else it.name }

        val adapter = ArrayAdapter(
            requireContext(), android.R.layout.simple_spinner_item, names
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        binding.spinnerFrom.adapter = adapter
        binding.spinnerTo.adapter = adapter

        if (stations.isNotEmpty()) {
            binding.spinnerFrom.setSelection(0)
            binding.spinnerTo.setSelection(stations.size - 1)
        }
    }

    private fun setupClickListeners() {
        binding.btnFindRoute.setOnClickListener {
            val fromIdx = binding.spinnerFrom.selectedItemPosition
            val toIdx = binding.spinnerTo.selectedItemPosition
            if (stationList.isEmpty()) return@setOnClickListener

            val from = stationList.getOrNull(fromIdx)
            val to = stationList.getOrNull(toIdx)

            if (from == null || to == null) return@setOnClickListener
            if (from.id == to.id) {
                Toast.makeText(
                    requireContext(), "Please select different stations", Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }
            viewModel.findRoute(from.id, to.id)
        }

        binding.btnPrev.setOnClickListener { viewModel.prevStep() }
        binding.btnNext.setOnClickListener { viewModel.nextStep() }
    }

    private fun updateStepCounter() {
        val total = viewModel.routeResult.value?.steps?.size ?: 0
        val current = (viewModel.currentStep.value ?: 0) + 1
        if (total > 0) {
            binding.tvStepCounter.text = "$current / $total"
        }
    }

    private fun updateNavButtons() {
        val step = viewModel.currentStep.value ?: 0
        val total = viewModel.routeResult.value?.steps?.size ?: 0
        binding.btnPrev.isEnabled = step > 0
        binding.btnNext.isEnabled = step < total - 1
        binding.btnPrev.alpha = if (step > 0) 1f else 0.3f
        binding.btnNext.alpha = if (step < total - 1) 1f else 0.3f
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
