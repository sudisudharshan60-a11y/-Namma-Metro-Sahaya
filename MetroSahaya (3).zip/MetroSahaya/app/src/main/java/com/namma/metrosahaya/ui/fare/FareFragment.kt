package com.namma.metrosahaya.ui.fare

import android.app.Application
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.asLiveData
import androidx.recyclerview.widget.LinearLayoutManager
import com.namma.metrosahaya.data.database.MetroDatabase
import com.namma.metrosahaya.data.database.MetroRepository
import com.namma.metrosahaya.databinding.FragmentFareBinding
import com.namma.metrosahaya.ui.MainViewModel
import com.namma.metrosahaya.ui.adapter.FareAdapter

class FareViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = MetroRepository(MetroDatabase.getDatabase(application))
    val fares = repository.getAllFares().asLiveData()
}

class FareFragment : Fragment() {

    private var _binding: FragmentFareBinding? = null
    private val binding get() = _binding!!

    private val viewModel: FareViewModel by viewModels()
    private val mainViewModel: MainViewModel by viewModels({ requireActivity() })
    private lateinit var fareAdapter: FareAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentFareBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        fareAdapter = FareAdapter()
        binding.rvFares.layoutManager = LinearLayoutManager(requireContext())
        binding.rvFares.adapter = fareAdapter

        viewModel.fares.observe(viewLifecycleOwner) { fares ->
            fareAdapter.updateData(fares, mainViewModel.isKannada.value == true)
        }

        mainViewModel.isKannada.observe(viewLifecycleOwner) { isKannada ->
            fareAdapter.updateLanguage(isKannada)
            updateTexts(isKannada)
        }
        updateTexts(mainViewModel.isKannada.value == true)
    }

    private fun updateTexts(isKannada: Boolean) {
        binding.tvFareTitle.text = if (isKannada) "ಶುಲ್ಕ ಕೋಷ್ಟಕ" else "Fare Chart"
        binding.tvFareNote.text = if (isKannada)
            "ಮಕ್ಕಳಿಗೆ (5–12 ವರ್ಷ) ಅರ್ಧ ಶುಲ್ಕ. 5 ವರ್ಷದ ಒಳಗೆ ಉಚಿತ."
        else
            "Children (5–12 yrs) pay half fare. Under 5 travel free."

        binding.tvCardTitle.text = if (isKannada) "ಕಾರ್ಡ್ ಟ್ಯಾಪ್ ವಿಧಾನ" else "How to Tap Your Card"
        binding.tvCardInstructions.text = if (isKannada)
            "🟢  ಹಸಿರು ದೀಪ = ಸರಿಯಾಗಿ ಟ್ಯಾಪ್ ಆಗಿದೆ\n" +
            "🔴  ಕೆಂಪು ದೀಪ = ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ\n" +
            "📲  ಕಾರ್ಡ್ ಅನ್ನು ಸ್ಕ್ಯಾನರ್ ಮೇಲೆ ಸಮತಟ್ಟಾಗಿ ಹಿಡಿದುಕೊಳ್ಳಿ"
        else
            "🟢  Green light = tapped correctly\n" +
            "🔴  Red light = try again\n" +
            "📲  Hold card flat on the scanner until the gate opens"
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
