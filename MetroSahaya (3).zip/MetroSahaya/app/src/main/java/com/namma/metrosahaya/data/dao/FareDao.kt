package com.namma.metrosahaya.data.dao

import androidx.room.*
import com.namma.metrosahaya.data.entity.FareEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FareDao {

    @Query("SELECT * FROM fares ORDER BY minStops ASC")
    fun getAllFares(): Flow<List<FareEntity>>

    @Query("SELECT fareRupees FROM fares WHERE :stops BETWEEN minStops AND maxStops LIMIT 1")
    suspend fun getFareForStops(stops: Int): Int?

    @Query("SELECT COUNT(*) FROM fares")
    suspend fun getCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(fares: List<FareEntity>)
}
