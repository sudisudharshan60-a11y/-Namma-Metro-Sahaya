package com.namma.metrosahaya.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.namma.metrosahaya.data.entity.ExitEntity
import com.namma.metrosahaya.databinding.ItemExitBinding

class ExitAdapter(private var isKannada: Boolean) : RecyclerView.Adapter<ExitAdapter.ExitViewHolder>() {

    private var exits = listOf<ExitEntity>()

    fun updateData(newExits: List<ExitEntity>, kannada: Boolean) {
        exits = newExits
        isKannada = kannada
        notifyDataSetChanged()
    }

    fun updateLanguage(kannada: Boolean) {
        isKannada = kannada
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExitViewHolder {
        val binding = ItemExitBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ExitViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ExitViewHolder, position: Int) {
        holder.bind(exits[position], isKannada)
    }

    override fun getItemCount() = exits.size

    class ExitViewHolder(private val binding: ItemExitBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(exit: ExitEntity, isKannada: Boolean) {
            binding.tvGateName.text = if (isKannada) exit.gateNameKannada else exit.gateName
            binding.tvLeadsTo.text = if (isKannada) exit.leadsToKannada else exit.leadsTo
            binding.tvLandmark.text = "📍 ${exit.landmark}"
        }
    }
}
