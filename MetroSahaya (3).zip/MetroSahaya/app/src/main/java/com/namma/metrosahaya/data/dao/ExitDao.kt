package com.namma.metrosahaya.data.dao

import androidx.room.*
import com.namma.metrosahaya.data.entity.ExitEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ExitDao {

    @Query("SELECT * FROM exits WHERE stationId = :stationId")
    fun getExitsForStation(stationId: String): Flow<List<ExitEntity>>

    @Query("SELECT * FROM exits WHERE stationId = :stationId")
    suspend fun getExitsForStationOnce(stationId: String): List<ExitEntity>

    @Query("SELECT COUNT(*) FROM exits")
    suspend fun getCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(exits: List<ExitEntity>)

    @Query("SELECT DISTINCT stationId FROM exits")
    suspend fun getStationsWithExits(): List<String>
}
