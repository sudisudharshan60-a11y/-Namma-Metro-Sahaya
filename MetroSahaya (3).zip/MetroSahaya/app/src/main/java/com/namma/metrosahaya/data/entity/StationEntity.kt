package com.namma.metrosahaya.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stations")
data class StationEntity(
    @PrimaryKey val id: String,
    val name: String,
    val nameKannada: String,
    val line: String,         // "purple" or "green"
    val orderIndex: Int,
    val isInterchange: Boolean = false
)
