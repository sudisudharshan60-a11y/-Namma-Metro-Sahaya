package com.namma.metrosahaya.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.namma.metrosahaya.data.entity.FareEntity
import com.namma.metrosahaya.databinding.ItemFareBinding

class FareAdapter : RecyclerView.Adapter<FareAdapter.FareViewHolder>() {

    private var fares = listOf<FareEntity>()
    private var isKannada = false

    fun updateData(newFares: List<FareEntity>, kannada: Boolean) {
        fares = newFares
        isKannada = kannada
        notifyDataSetChanged()
    }

    fun updateLanguage(kannada: Boolean) {
        isKannada = kannada
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FareViewHolder {
        val binding = ItemFareBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FareViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FareViewHolder, position: Int) {
        holder.bind(fares[position], isKannada)
    }

    override fun getItemCount() = fares.size

    class FareViewHolder(private val binding: ItemFareBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(fare: FareEntity, isKannada: Boolean) {
            val stopsText = if (fare.maxStops >= 99) "${fare.minStops}+" else
                if (fare.minStops == fare.maxStops) "${fare.minStops}" else "${fare.minStops}–${fare.maxStops}"
            binding.tvStops.text = stopsText
            binding.tvDistance.text = fare.distanceKm
            binding.tvFare.text = "₹${fare.fareRupees}"
        }
    }
}
