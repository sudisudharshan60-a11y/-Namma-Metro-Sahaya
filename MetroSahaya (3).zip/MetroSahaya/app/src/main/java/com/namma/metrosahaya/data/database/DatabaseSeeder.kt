package com.namma.metrosahaya.data.database

import com.namma.metrosahaya.data.entity.ExitEntity
import com.namma.metrosahaya.data.entity.FareEntity
import com.namma.metrosahaya.data.entity.StationEntity

object DatabaseSeeder {

    suspend fun seedData(database: MetroDatabase) {
        seedStations(database)
        seedExits(database)
        seedFares(database)
    }

    private suspend fun seedStations(database: MetroDatabase) {
        val stations = listOf(
            // ── Purple Line (East → West) ──
            StationEntity("byp",  "Baiyappanahalli",           "ಬೈಯಪ್ಪನಹಳ್ಳಿ",                "purple", 1),
            StationEntity("swg",  "Swami Vivekananda Road",    "ಸ್ವಾಮಿ ವಿವೇಕಾನಂದ ರಸ್ತೆ",      "purple", 2),
            StationEntity("inm",  "Indiranagar",               "ಇಂದಿರಾನಗರ",                   "purple", 3),
            StationEntity("hal",  "Halasuru",                  "ಹಾಳಸೂರು",                     "purple", 4),
            StationEntity("tri",  "Trinity",                   "ಟ್ರಿನಿಟಿ",                    "purple", 5),
            StationEntity("mgs",  "MG Road",                   "ಎಂಜಿ ರಸ್ತೆ",                  "purple", 6),
            StationEntity("cub",  "Cubbon Park",               "ಕಬ್ಬನ್ ಪಾರ್ಕ್",               "purple", 7),
            StationEntity("maj",  "Majestic",                  "ಮೆಜಸ್ಟಿಕ್",                   "purple", 8,  true),
            StationEntity("cit",  "City Railway Station",      "ಸಿಟಿ ರೈಲ್ವೆ ನಿಲ್ದಾಣ",         "purple", 9),
            StationEntity("mgs2", "Magadi Road",               "ಮಾಗಡಿ ರಸ್ತೆ",                 "purple", 10),
            StationEntity("hos",  "Hosahalli",                 "ಹೊಸಹಳ್ಳಿ",                    "purple", 11),
            StationEntity("vin",  "Vijayanagar",               "ವಿಜಯನಗರ",                     "purple", 12),
            StationEntity("att",  "Attiguppe",                 "ಅತ್ತಿಗುಪ್ಪೆ",                 "purple", 13),
            StationEntity("dav",  "Deepanjali Nagar",          "ದೀಪಾಂಜಲಿ ನಗರ",               "purple", 14),
            StationEntity("mys",  "Mysuru Road",               "ಮೈಸೂರು ರಸ್ತೆ",                "purple", 15),

            // ── Green Line (North → South) ──
            StationEntity("nag",  "Nagasandra",                "ನಾಗಸಂದ್ರ",                    "green",  1),
            StationEntity("das",  "Dasarahalli",               "ದಸರಹಳ್ಳಿ",                    "green",  2),
            StationEntity("jal",  "Jalahalli",                 "ಜಾಲಹಳ್ಳಿ",                    "green",  3),
            StationEntity("pet",  "Peenya Industry",           "ಪೀಣ್ಯ ಇಂಡಸ್ಟ್ರಿ",             "green",  4),
            StationEntity("pee",  "Peenya",                    "ಪೀಣ್ಯ",                        "green",  5),
            StationEntity("goo",  "Goraguntepalya",            "ಗೊರಗುಂಟೆಪಾಳ್ಯ",               "green",  6),
            StationEntity("yel",  "Yeshwanthpur",              "ಯಶವಂತಪುರ",                    "green",  7),
            StationEntity("san",  "Sandal Soap Factory",       "ಸ್ಯಾಂಡಲ್ ಸೋಪ್ ಫ್ಯಾಕ್ಟರಿ",     "green",  8),
            StationEntity("maj2", "Majestic",                  "ಮೆಜಸ್ಟಿಕ್",                   "green",  9,  true),
            StationEntity("vis",  "Sir M Visvesvaraya",        "ಸರ್ ಎಂ ವಿಶ್ವೇಶ್ವರಯ್ಯ",        "green",  10),
            StationEntity("kri",  "Krishnarajendra Market",    "ಕೃಷ್ಣರಾಜೇಂದ್ರ ಮಾರ್ಕೆಟ್",      "green",  11),
            StationEntity("nat",  "National College",          "ನ್ಯಾಷನಲ್ ಕಾಲೇಜು",             "green",  12),
            StationEntity("lan",  "Lalbagh",                   "ಲಾಲ್‌ಬಾಗ್",                   "green",  13),
            StationEntity("sec",  "South End Circle",          "ಸೌತ್ ಎಂಡ್ ಸರ್ಕಲ್",            "green",  14),
            StationEntity("jay",  "Jayanagar",                 "ಜಯನಗರ",                       "green",  15),
            StationEntity("rpc",  "RV Road",                   "ಆರ್‌ವಿ ರಸ್ತೆ",                "green",  16),
            StationEntity("ban",  "Banashankari",              "ಬನಶಂಕರಿ",                     "green",  17),
            StationEntity("jpp",  "Jaya Prakash Nagar",        "ಜಯಪ್ರಕಾಶ ನಗರ",               "green",  18),
            StationEntity("ylc",  "Yelachenahalli",            "ಯಲಚೇನಹಳ್ಳಿ",                  "green",  19)
        )
        database.stationDao().insertAll(stations)
    }

    private suspend fun seedExits(database: MetroDatabase) {
        val exits = listOf(
            ExitEntity(stationId = "maj",  gateName = "Gate 1", gateNameKannada = "ಗೇಟ್ 1",
                leadsTo = "KSRTC Bus Stand",        leadsToKannada = "ಕೆಎಸ್ಆರ್ಟಿಸಿ ಬಸ್ ನಿಲ್ದಾಣ",
                landmark = "Near McDonald's"),
            ExitEntity(stationId = "maj",  gateName = "Gate 2", gateNameKannada = "ಗೇಟ್ 2",
                leadsTo = "City Railway Station",   leadsToKannada = "ಸಿಟಿ ರೈಲ್ವೆ ನಿಲ್ದಾಣ",
                landmark = "Foot over bridge"),
            ExitEntity(stationId = "maj",  gateName = "Gate 3", gateNameKannada = "ಗೇಟ್ 3",
                leadsTo = "Kempe Gowda Bus Stand",  leadsToKannada = "ಕೆಂಪೇಗೌಡ ಬಸ್ ನಿಲ್ದಾಣ",
                landmark = "Platform 1 side"),
            ExitEntity(stationId = "inm",  gateName = "Gate 1", gateNameKannada = "ಗೇಟ್ 1",
                leadsTo = "100 Feet Road",          leadsToKannada = "100 ಅಡಿ ರಸ್ತೆ",
                landmark = "Near CMH Hospital"),
            ExitEntity(stationId = "inm",  gateName = "Gate 2", gateNameKannada = "ಗೇಟ್ 2",
                leadsTo = "12th Main Road",         leadsToKannada = "12ನೇ ಮೇನ್ ರಸ್ತೆ",
                landmark = "Near HDFC Bank"),
            ExitEntity(stationId = "mgs",  gateName = "Gate 1", gateNameKannada = "ಗೇಟ್ 1",
                leadsTo = "Brigade Road",           leadsToKannada = "ಬ್ರಿಗೇಡ್ ರಸ್ತೆ",
                landmark = "Near Barton Centre"),
            ExitEntity(stationId = "mgs",  gateName = "Gate 2", gateNameKannada = "ಗೇಟ್ 2",
                leadsTo = "Commercial Street",      leadsToKannada = "ಕಮರ್ಷಿಯಲ್ ಸ್ಟ್ರೀಟ್",
                landmark = "Opposite MG Road park"),
            ExitEntity(stationId = "lan",  gateName = "Gate 1", gateNameKannada = "ಗೇಟ್ 1",
                leadsTo = "Lalbagh Botanical Garden", leadsToKannada = "ಲಾಲ್‌ಬಾಗ್ ಬೊಟಾನಿಕಲ್ ಗಾರ್ಡನ್",
                landmark = "East gate entrance"),
            ExitEntity(stationId = "yel",  gateName = "Gate 1", gateNameKannada = "ಗೇಟ್ 1",
                leadsTo = "Yeshwanthpur Railway Station", leadsToKannada = "ಯಶವಂತಪುರ ರೈಲ್ವೆ ನಿಲ್ದಾಣ",
                landmark = "500m walk, follow signs"),
            ExitEntity(stationId = "ban",  gateName = "Gate 1", gateNameKannada = "ಗೇಟ್ 1",
                leadsTo = "Banashankari Temple",    leadsToKannada = "ಬನಶಂಕರಿ ದೇವಸ್ಥಾನ",
                landmark = "Near bus terminus"),
            ExitEntity(stationId = "cit",  gateName = "Gate 1", gateNameKannada = "ಗೇಟ್ 1",
                leadsTo = "KSR Bengaluru City Station", leadsToKannada = "ಕೆಎಸ್ಆರ್ ಬೆಂಗಳೂರು ನಿಲ್ದಾಣ",
                landmark = "Direct footbridge access")
        )
        database.exitDao().insertAll(exits)
    }

    private suspend fun seedFares(database: MetroDatabase) {
        val fares = listOf(
            FareEntity(minStops = 0,  maxStops = 1,  fareRupees = 10, distanceKm = "0 – 2 km"),
            FareEntity(minStops = 2,  maxStops = 2,  fareRupees = 15, distanceKm = "2 – 4 km"),
            FareEntity(minStops = 3,  maxStops = 3,  fareRupees = 20, distanceKm = "4 – 6 km"),
            FareEntity(minStops = 4,  maxStops = 5,  fareRupees = 25, distanceKm = "6 – 10 km"),
            FareEntity(minStops = 6,  maxStops = 8,  fareRupees = 30, distanceKm = "10 – 14 km"),
            FareEntity(minStops = 9,  maxStops = 99, fareRupees = 40, distanceKm = "14+ km")
        )
        database.fareDao().insertAll(fares)
    }
}
