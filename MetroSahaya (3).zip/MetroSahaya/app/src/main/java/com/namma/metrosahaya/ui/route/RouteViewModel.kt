package com.namma.metrosahaya.ui.route

import android.app.Application
import androidx.lifecycle.*
import com.namma.metrosahaya.data.database.MetroDatabase
import com.namma.metrosahaya.data.database.MetroRepository
import com.namma.metrosahaya.data.entity.StationEntity
import com.namma.metrosahaya.model.RouteResult
import com.namma.metrosahaya.model.RouteStep
import kotlinx.coroutines.launch

class RouteViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = MetroRepository(MetroDatabase.getDatabase(application))

    val allStations: LiveData<List<StationEntity>> =
        repository.getAllStations().asLiveData()

    private val _routeResult = MutableLiveData<RouteResult?>()
    val routeResult: LiveData<RouteResult?> = _routeResult

    private val _currentStep = MutableLiveData(0)
    val currentStep: LiveData<Int> = _currentStep

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error

    var fromStationId: String? = null
    var toStationId: String? = null

    init {
        viewModelScope.launch {
            repository.seedIfEmpty()
        }
    }

    fun findRoute(fromId: String, toId: String) {
        fromStationId = fromId
        toStationId = toId
        viewModelScope.launch {
            _isLoading.value = true
            _error.value = null
            try {
                val result = repository.findRoute(fromId, toId)
                _routeResult.value = result
                _currentStep.value = 0
                if (result == null) _error.value = "Could not find a route. Please select different stations."
            } catch (e: Exception) {
                _error.value = "Error: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun nextStep() {
        val maxStep = (_routeResult.value?.steps?.size ?: 1) - 1
        _currentStep.value = ((_currentStep.value ?: 0) + 1).coerceAtMost(maxStep)
    }

    fun prevStep() {
        _currentStep.value = ((_currentStep.value ?: 0) - 1).coerceAtLeast(0)
    }

    fun setStep(index: Int) {
        _currentStep.value = index
    }

    fun refreshCurrentStep() {
        _currentStep.value = _currentStep.value
    }

    val currentStepData: LiveData<RouteStep?> = MediatorLiveData<RouteStep?>().apply {
        addSource(_routeResult) { result ->
            val step = _currentStep.value ?: 0
            value = result?.steps?.getOrNull(step)
        }
        addSource(_currentStep) { step ->
            value = _routeResult.value?.steps?.getOrNull(step)
        }
    }
}
