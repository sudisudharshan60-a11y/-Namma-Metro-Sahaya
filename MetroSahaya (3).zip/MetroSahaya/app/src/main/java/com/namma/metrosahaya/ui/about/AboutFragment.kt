package com.namma.metrosahaya.ui.about

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.namma.metrosahaya.databinding.FragmentAboutBinding
import com.namma.metrosahaya.ui.MainViewModel

class AboutFragment : Fragment() {
    private var _binding: FragmentAboutBinding? = null
    private val binding get() = _binding!!
    private val mainViewModel: MainViewModel by viewModels({ requireActivity() })

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAboutBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mainViewModel.isKannada.observe(viewLifecycleOwner) { isKannada ->
            binding.tvAboutTitle.text = if (isKannada) "ನಮ್ಮ ಮೆಟ್ರೋ ಸಹಾಯ" else "Namma-Metro Sahaya"
            binding.tvAboutSubtitle.text = if (isKannada)
                "ಮೊದಲ ಬಾರಿ ಮೆಟ್ರೋ ಬಳಸುವವರಿಗಾಗಿ ಮಾರ್ಗದರ್ಶಿ"
            else
                "First-Timer's Metro Guide for Bengaluru"
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
