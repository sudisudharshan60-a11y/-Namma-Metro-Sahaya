# Add project specific ProGuard rules here.
-keep class com.namma.metrosahaya.data.** { *; }
-keep class com.namma.metrosahaya.model.** { *; }
